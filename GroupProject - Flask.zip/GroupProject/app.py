from flask import Flask, render_template, request
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, SelectField
import requests
import logging

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

US_STATES = [
    ('AL', 'Alabama'), ('AK', 'Alaska'), ('AZ', 'Arizona'), ('AR', 'Arkansas'), ('CA', 'California'),
    ('CO', 'Colorado'), ('CT', 'Connecticut'), ('DE', 'Delaware'), ('FL', 'Florida'), ('GA', 'Georgia'),
    ('HI', 'Hawaii'), ('ID', 'Idaho'), ('IL', 'Illinois'), ('IN', 'Indiana'), ('IA', 'Iowa'),
    ('KS', 'Kansas'), ('KY', 'Kentucky'), ('LA', 'Louisiana'), ('ME', 'Maine'), ('MD', 'Maryland'),
    ('MA', 'Massachusetts'), ('MI', 'Michigan'), ('MN', 'Minnesota'), ('MS', 'Mississippi'),
    ('MO', 'Missouri'), ('MT', 'Montana'), ('NE', 'Nebraska'), ('NV', 'Nevada'), ('NH', 'New Hampshire'),
    ('NJ', 'New Jersey'), ('NM', 'New Mexico'), ('NY', 'New York'), ('NC', 'North Carolina'),
    ('ND', 'North Dakota'), ('OH', 'Ohio'), ('OK', 'Oklahoma'), ('OR', 'Oregon'), ('PA', 'Pennsylvania'),
    ('RI', 'Rhode Island'), ('SC', 'South Carolina'), ('SD', 'South Dakota'), ('TN', 'Tennessee'),
    ('TX', 'Texas'), ('UT', 'Utah'), ('VT', 'Vermont'), ('VA', 'Virginia'), ('WA', 'Washington'),
    ('WV', 'West Virginia'), ('WI', 'Wisconsin'), ('WY', 'Wyoming')
]

class GeoForm(FlaskForm):
    state = SelectField('State', choices=US_STATES)
    city = StringField('City')
    submit = SubmitField('Submit')

API_URL = 'http://geodb-free-service.wirefreethought.com/v1/geo/places'

def fetch_city_data(city, state):
    params = {
        "namePrefix": city,
        "countryIds": "US",
        "regionCode": state,
        "types": "CITY",
        "limit": 10,
        "offset": 0
    }
    headers = {'Accept': 'application/json'}
    response = requests.get(API_URL, headers=headers, params=params)
    if response.status_code == 200:
        return response.json().get('data')
    logging.error(f"API call failed with status code {response.status_code}, {response.text}")
    return None

@app.route('/', methods=['GET', 'POST'])
def index():
    form = GeoForm()
    cities_data = None
    if form.validate_on_submit():
        cities_data = fetch_city_data(form.city.data, form.state.data)
    return render_template('index.html', form=form, cities_data=cities_data)

if __name__ == '__main__':
    app.run(debug=True)
